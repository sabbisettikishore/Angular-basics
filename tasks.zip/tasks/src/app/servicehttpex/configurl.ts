export class Configurl {
    
        urlData='http://dummy.restapiexample.com/api/v1/';
       
    
}
