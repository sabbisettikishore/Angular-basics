import { Configurl } from './configurl';

describe('Configurl', () => {
  it('should create an instance', () => {
    expect(new Configurl()).toBeTruthy();
  });
});
