import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pure-and-impure-pipes',
  templateUrl: './pure-and-impure-pipes.component.html',
  styleUrls: ['./pure-and-impure-pipes.component.scss']
})
export class PureAndImpurePipesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
