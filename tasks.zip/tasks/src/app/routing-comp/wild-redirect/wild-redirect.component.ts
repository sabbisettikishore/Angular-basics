import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wild-redirect',
  templateUrl: './wild-redirect.component.html',
  styleUrls: ['./wild-redirect.component.scss']
})
export class WildRedirectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
