import { StructuralDirective } from './structural.directive';

describe('StructuralDirective', () => {
  it('should create an instance', () => {
    const directive = new StructuralDirective();
    expect(directive).toBeTruthy();
  });
});
