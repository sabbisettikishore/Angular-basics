import { CopyPasteDirective } from './copy-paste.directive';

describe('CopyPasteDirective', () => {
  it('should create an instance', () => {
    const directive = new CopyPasteDirective();
    expect(directive).toBeTruthy();
  });
});
