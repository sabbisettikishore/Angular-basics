import { CustomvalidDirective } from './customvalid.directive';

describe('CustomvalidDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomvalidDirective();
    expect(directive).toBeTruthy();
  });
});
